import pygame
from pygame import mixer
from pygame.locals import *
import random
import math
import os

pygame.mixer.pre_init(44100, -16, 2 , 512)
mixer.init()
pygame.init()

# background music
pygame.mixer.music.load(os.path.join("Audio Assets", "backgroundMusic.mp3"))
pygame.mixer.music.set_volume(0.4) # Adjust volume (0.0 to 1.0)
pygame.mixer.music.play(loops=-1) # Play indefinitely

# define fps
clock = pygame.time.Clock()
fps = 60

screen_width = 500
screen_height = 800

screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption('Invadio')

# font
font_game_regular_path = os.path.join("Fonts", "Minecraft.ttf")
font_title_path = os.path.join("Fonts", "Vermin Vibes 1989.ttf")

font30 = pygame.font.Font(font_game_regular_path, 30)
font40 = pygame.font.Font(font_game_regular_path, 40)
font_instructions = pygame.font.Font(font_game_regular_path, 22)

font_ui = pygame.font.SysFont('Arial', 22)
font_title = pygame.font.Font(font_title_path, 100)
font_subtitle = pygame.font.SysFont('Verdana', 20, italic=True)

font_slang = pygame.font.Font(font_title_path, 45)
font_authors_section_title = pygame.font.Font(font_title_path, 45)

# rgb color palette
purple_blue_palette = [
    (0, 100, 255),
    (70, 70, 220),
    (138, 43, 226),
    (128, 0, 128),
    (100, 100, 255),
    (60, 0, 190)
]

# sound effects
explosion_fx = pygame.mixer.Sound(os.path.join("Audio Assets", "explosionfx.mp3"))
explosion_fx.set_volume(0.25)
spaceshipGotHit_fx = pygame.mixer.Sound(os.path.join("Audio Assets", "spaceshipGotHit_fx.mp3"))
spaceshipGotHit_fx.set_volume(0.25)
alienGotHit_fx = pygame.mixer.Sound(os.path.join("Audio Assets", "alienGotHit_fx.mp3"))
alienGotHit_fx.set_volume(0.25)
shooting_fx = pygame.mixer.Sound(os.path.join("Audio Assets", "shootingfx.mp3"))
shooting_fx.set_volume(0.25)
# Assuming boss sounds use the same explosion and shooting fx but could be different files
boss_hit_fx = pygame.mixer.Sound(os.path.join("Audio Assets", "explosionfx.mp3"))
boss_hit_fx.set_volume(0.3)
boss_shoot_fx = pygame.mixer.Sound(os.path.join("Audio Assets", "shootingfx.mp3"))
boss_shoot_fx.set_volume(0.4)
boss_death_fx = pygame.mixer.Sound(os.path.join("Audio Assets", "explosionfx.mp3"))
boss_death_fx.set_volume(0.6)

# define game var
rows = 5
cols = 5
enemy_cooldown_level1 = 1700
enemy_cooldown_level2 = 1000
last_enemy_shot = pygame.time.get_ticks()
countdown = 3
initial_countdown_duration = 3
lastCount = pygame.time.get_ticks()

current_level = 1
max_levels = 3

# define colours
red = (244, 0 ,9)
green = (0, 165, 80)
white = (255, 255, 255)
instruction_color = (200, 200, 200)
boss_health_bar_bg_color = (50,50,50)
boss_health_bar_fill_color = (200,0,0)
boss_health_bar_border_color = (220,220,220)

# load image
bg_img_orig = pygame.image.load(os.path.join("Background Assets", "Background 1.png")).convert()
bg_boss_img_orig = bg_img_orig.copy()
bg_boss_img_orig.fill((40,0,0, 150), special_flags=pygame.BLEND_RGB_ADD)

enemy1_img_orig = pygame.image.load(os.path.join("Enemy Assets", "Enemy 1.png")).convert_alpha()
enemy2_img_orig = pygame.image.load(os.path.join("Enemy Assets", "Enemy 2.png")).convert_alpha()

player_ship_img_orig = pygame.image.load(os.path.join("Spaceship Assets", "Alien.png")).convert_alpha()
player_ship_l3_img_orig = pygame.image.load(os.path.join("Spaceship Assets", "Alien 2.PNG")).convert_alpha() # Note: Case might matter for "PNG" vs "png"
player_bullet_img_orig = pygame.image.load(os.path.join("Bullet Assets", "Bullet 2.png")).convert_alpha()

enemy_bullet_img_orig = pygame.image.load(os.path.join("Bullet Assets", "E bullet 2.png")).convert_alpha() # Assuming enemy bullets are in "Bullet Assets"
mechabot_img_orig = pygame.image.load(os.path.join("MechaBot Assets", "Full body mecha bot.png")).convert_alpha()

explosion_strip = [pygame.image.load(os.path.join("Explosion Assets", f"Explosion {i}.png")).convert_alpha() for i in range(1, 5)]
enemy_explosion_strip = [pygame.image.load(os.path.join("Enemy Explosion Assets", f"E explosion {i}.png")).convert_alpha() for i in range(1, 5)]

bg_img = pygame.transform.scale(bg_img_orig, (screen_width, screen_height))
bg_boss_img = pygame.transform.scale(bg_boss_img_orig, (screen_width, screen_height))

def draw_bg():
    if game_state == "playing" and current_level == 3:
        screen.blit(bg_boss_img, (0,0))
    else:
        screen.blit(bg_img, (0, 0))

def draw_text(text, font, text_col, x, y, center=False): # Standard text drawing
    img = font.render(text, True, text_col)
    if center:
        text_rect = img.get_rect(center=(x,y))
        screen.blit(img, text_rect)
    else:
        screen.blit(img, (x,y))

def draw_multicolor_text(text_str, font_obj, x_center, y_top_requested, color_palette, time_offset, is_centered_horizontally=True):
    total_width = 0
    char_surfaces_widths = []

    for i, char_val in enumerate(text_str):
        color_index = (i + int(time_offset)) % len(color_palette)
        char_color = color_palette[color_index]
        char_surf = font_obj.render(char_val, True, char_color)
        char_surfaces_widths.append({'surface': char_surf, 'width': char_surf.get_width()})
        total_width += char_surf.get_width()

    current_x = x_center
    if is_centered_horizontally:
        current_x = x_center - total_width / 2

    for item in char_surfaces_widths:
        screen.blit(item['surface'], (current_x, y_top_requested))
        current_x += item['width']


def draw_player_health_bar(player_sprite):
    if player_sprite and player_sprite.alive():
        bar_x = player_sprite.rect.x
        bar_y = player_sprite.rect.bottom + 5
        bar_width = player_sprite.rect.width
        bar_height = 10

        if bar_y + bar_height > screen_height:
            bar_y = screen_height - bar_height - 1
        if bar_y < player_sprite.rect.bottom:
             bar_y = player_sprite.rect.bottom + 2

        pygame.draw.rect(screen, red, (bar_x, bar_y, bar_width, bar_height))
        if player_sprite.health_remain > 0:
            health_width = int(bar_width * (player_sprite.health_remain / player_sprite.health_start))
            pygame.draw.rect(screen, green, (bar_x, bar_y, health_width, bar_height))

def draw_boss_health_bar(boss_sprite):
    if boss_sprite and boss_sprite.alive():
        health_percentage = max(0, boss_sprite.current_health / boss_sprite.max_health)
        bar_actual_width = screen_width * 0.75
        bar_actual_height = 20
        bar_x_pos = (screen_width - bar_actual_width) / 2
        bar_y_pos = 10

        pygame.draw.rect(screen, boss_health_bar_bg_color, (bar_x_pos, bar_y_pos, bar_actual_width, bar_actual_height))
        pygame.draw.rect(screen, boss_health_bar_fill_color, (bar_x_pos, bar_y_pos, bar_actual_width * health_percentage, bar_actual_height))
        pygame.draw.rect(screen, boss_health_bar_border_color, (bar_x_pos, bar_y_pos, bar_actual_width, bar_actual_height), 2)
        draw_text("MECHA BOT", font_ui, white, screen_width / 2, bar_y_pos + bar_actual_height / 2, center=True)

class Spaceship(pygame.sprite.Sprite):
    def __init__(self, x, y, health):
        pygame.sprite.Sprite.__init__(self)
        self.scaled_width = 138
        self.scaled_height = 138
        self.current_image_orig = player_ship_img_orig
        self.image = pygame.transform.scale(self.current_image_orig, (self.scaled_width, self.scaled_height))
        self.rect = self.image.get_rect(center=[x, y])
        self.health_start = health
        self.health_remain = health
        self.last_shot = pygame.time.get_ticks()
        self.mask = pygame.mask.from_surface(self.image)
        self.is_morphed = False

    def update(self):
        speed = 7
        cooldown  = 380
        player_died = False

        key = pygame.key.get_pressed()
        if key[pygame.K_LEFT] and self.rect.left > 0: self.rect.x -= speed
        if key[pygame.K_RIGHT] and self.rect.right < screen_width: self.rect.x += speed

        time_now = pygame.time.get_ticks()
        if key[pygame.K_SPACE] and time_now - self.last_shot > cooldown:
            if shooting_fx: shooting_fx.play()
            bullet = Bullets(self.rect.centerx, self.rect.top)
            bullet_group.add(bullet)
            self.last_shot = time_now

        self.mask = pygame.mask.from_surface(self.image)

        if self.health_remain <= 0:
            if explosion_fx: explosion_fx.play()
            explosion = Explosion(self.rect.centerx, self.rect.centery, 3)
            explosion_group.add(explosion)
            self.kill()
            player_died = True
        return player_died

    def morph_to_level3_form(self):
        if not self.is_morphed:
            original_center = self.rect.center
            self.current_image_orig = player_ship_l3_img_orig
            self.image = pygame.transform.scale(self.current_image_orig, (self.scaled_width, self.scaled_height))
            self.rect = self.image.get_rect(center=original_center)
            self.mask = pygame.mask.from_surface(self.image)
            self.is_morphed = True

    def revert_to_normal_form(self):
        if self.is_morphed:
            original_center = self.rect.center
            self.current_image_orig = player_ship_img_orig
            self.image = pygame.transform.scale(self.current_image_orig, (self.scaled_width, self.scaled_height))
            self.rect = self.image.get_rect(center=original_center)
            self.mask = pygame.mask.from_surface(self.image)
            self.is_morphed = False

class Bullets(pygame.sprite.Sprite):
    def __init__(self, x, y):
        pygame.sprite.Sprite.__init__(self)
        scaled_width = 8
        scaled_height = 15
        self.image = pygame.transform.scale(player_bullet_img_orig, (scaled_width, scaled_height))
        self.rect = self.image.get_rect(center=[x,y])
        self.mask = pygame.mask.from_surface(self.image)

    def update(self):
        self.rect.y -= 8
        if self.rect.bottom < 0: self.kill()

        hit_enemies = pygame.sprite.spritecollide(self, enemy_group, False, pygame.sprite.collide_mask)
        if hit_enemies:
            self.kill()
            for enemy in hit_enemies:
                enemy.health -= 1
                if enemy.health <= 0:
                    if alienGotHit_fx: alienGotHit_fx.play()
                    explosion = Explosion(enemy.rect.centerx, enemy.rect.centery, 2)
                    explosion_group.add(explosion)
                    enemy.kill()

        if current_level == 3 and mechabot_group.sprite and mechabot_group.sprite.alive():
            if pygame.sprite.collide_mask(self, mechabot_group.sprite):
                self.kill()
                mechabot_group.sprite.take_damage(1)

class Enemies(pygame.sprite.Sprite):
    def __init__(self, x, y, enemy_type):
        pygame.sprite.Sprite.__init__(self)
        self.enemy_type = enemy_type
        if self.enemy_type == 1:
            scaled_width = 80
            scaled_height = 70
            self.image_orig_ref = enemy1_img_orig
            self.health = 1
        elif self.enemy_type == 2:
            scaled_width = 80
            scaled_height = 70
            self.image_orig_ref = enemy2_img_orig
            self.health = 2
        else:
            scaled_width = 55
            scaled_height = 45
            self.image_orig_ref = enemy1_img_orig
            self.health = 1
        self.image = pygame.transform.scale(self.image_orig_ref, (scaled_width, scaled_height))
        self.rect = self.image.get_rect(center=[x,y])
        self.move_counter = 0
        self.move_direction = 1
        self.mask = pygame.mask.from_surface(self.image)

    def update(self):
        self.rect.x += 1 * self.move_direction
        self.move_counter += 1
        if abs(self.move_counter) > 70:
            self.move_direction *= -1
            self.move_counter *= self.move_direction

class Enemy_Bullets(pygame.sprite.Sprite):
    def __init__(self, x, y, speed, image_ref=enemy_bullet_img_orig, scale_w=10, scale_h=16, damage_val=0.5):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.transform.scale(image_ref, (scale_w, scale_h))
        self.rect = self.image.get_rect(center=[x,y])
        self.speed = speed
        self.damage = damage_val
        self.mask = pygame.mask.from_surface(self.image)

    def update(self):
        self.rect.y += self.speed
        if self.rect.top > screen_height: self.kill()

        if spaceship_group.sprite and spaceship_group.sprite.alive():
            if pygame.sprite.collide_mask(self, spaceship_group.sprite):
                self.kill()
                if spaceshipGotHit_fx: spaceshipGotHit_fx.play()
                spaceship_group.sprite.health_remain -= self.damage
                expl = Enemy_Explosion(self.rect.centerx, self.rect.centery, 1)
                enemy_explosion_group.add(expl)

class Explosion(pygame.sprite.Sprite):
    def __init__(self, x, y, size):
        pygame.sprite.Sprite.__init__(self)
        self.images = []
        for img_orig in explosion_strip:
            if size == 1: img = pygame.transform.scale(img_orig, (150, 150))
            elif size == 2: img = pygame.transform.scale(img_orig, (150, 150))
            elif size == 3: img = pygame.transform.scale(img_orig, (200, 200))
            elif size == 4: img = pygame.transform.scale(img_orig, (300, 300))
            else: img = pygame.transform.scale(img_orig, (50,50))
            self.images.append(img)
        self.index = 0
        if not self.images: self.kill(); return
        self.image = self.images[self.index]
        self.rect = self.image.get_rect(center=[x,y])
        self.counter = 0
        self.animation_speed = 3

    def update(self):
        if not self.images: return
        self.counter += 1
        if self.counter >= self.animation_speed and self.index < len(self.images) - 1:
            self.counter = 0; self.index += 1; self.image = self.images[self.index]
        if self.index >= len(self.images) - 1 and self.counter >= self.animation_speed:
            self.kill()

class Enemy_Explosion(Explosion):
     def __init__(self, x, y, size):
        super().__init__(x, y, size)
        self.images = []
        for img_orig in enemy_explosion_strip:
            if size == 1: img = pygame.transform.scale(img_orig, (30, 30))
            else: img = pygame.transform.scale(img_orig, (30,30))
            self.images.append(img)
        if self.images:
            self.index = 0; self.image = self.images[self.index]; self.rect = self.image.get_rect(center=[x,y])
        else: self.kill()

class MechaBot(pygame.sprite.Sprite):
    def __init__(self, x, y):
        pygame.sprite.Sprite.__init__(self)
        boss_width, boss_height = 180, 200
        self.image_orig = pygame.transform.scale(mechabot_img_orig, (boss_width, boss_height))
        self.image = self.image_orig.copy()
        self.rect = self.image.get_rect(center=(x,y))
        self.mask = pygame.mask.from_surface(self.image)
        self.max_health = 100
        self.current_health = self.max_health
        self.state = "entering"
        self.entry_target_y = screen_height * 0.20
        self.entry_speed = 4
        self.patrol_speed = 1.5
        self.patrol_direction = 1
        self.patrol_min_x = boss_width * 0.5 + 30
        self.patrol_max_x = screen_width - (boss_width * 0.5) - 30
        self.last_any_attack_time = pygame.time.get_ticks()
        self.general_attack_cooldown = 1800
        self.barrage_shots_fired = 0
        self.barrage_shots_total = 5
        self.barrage_shot_interval = 120
        self.last_barrage_shot_time = 0
        self.death_anim_start_time = 0
        self.death_explosion_count = 0
        self.max_death_explosions = 12
        self.death_explosion_delay = 150

    def take_damage(self, amount):
        if self.state == "dying": return
        self.current_health -= amount
        if boss_hit_fx: boss_hit_fx.play()
        self.image.fill((200,50,50, 100), special_flags=pygame.BLEND_RGB_ADD)
        if self.current_health <= 0:
            self.current_health = 0
            self.state = "dying"
            self.death_anim_start_time = pygame.time.get_ticks()
            if boss_death_fx: boss_death_fx.play()

    def update(self):
        current_time = pygame.time.get_ticks()
        if self.state != "dying":
            self.image = self.image_orig.copy()

        if self.state == "entering":
            self.rect.y += self.entry_speed
            if self.rect.centery >= self.entry_target_y:
                self.rect.centery = self.entry_target_y
                self.state = "patrolling"
                self.last_any_attack_time = current_time
        elif self.state == "patrolling":
            self.rect.x += self.patrol_speed * self.patrol_direction
            if self.rect.centerx >= self.patrol_max_x: self.patrol_direction = -1
            elif self.rect.centerx <= self.patrol_min_x: self.patrol_direction = 1
            if current_time - self.last_any_attack_time > self.general_attack_cooldown:
                self.choose_attack_pattern(current_time)
        elif self.state == "attack_standard":
            self.fire_bullet_type("standard")
            self.state = "patrolling"
            self.last_any_attack_time = current_time
        elif self.state == "attack_barrage":
            if self.barrage_shots_fired < self.barrage_shots_total and \
               current_time - self.last_barrage_shot_time > self.barrage_shot_interval:
                self.fire_bullet_type("barrage_shot")
                self.barrage_shots_fired += 1
                self.last_barrage_shot_time = current_time
            if self.barrage_shots_fired >= self.barrage_shots_total:
                self.state = "patrolling"
                self.last_any_attack_time = current_time
        elif self.state == "attack_spread":
            self.fire_bullet_type("spread")
            self.state = "patrolling"
            self.last_any_attack_time = current_time
        elif self.state == "dying":
            if current_time - self.death_anim_start_time > self.death_explosion_delay * self.death_explosion_count \
               and self.death_explosion_count < self.max_death_explosions:
                rx = self.rect.centerx + random.randint(-self.rect.width//3, self.rect.width//3)
                ry = self.rect.centery + random.randint(-self.rect.height//3, self.rect.height//3)
                expl = Explosion(rx, ry, random.choice([3,4]))
                explosion_group.add(expl)
                self.death_explosion_count += 1
            if self.death_explosion_count >= self.max_death_explosions:
                boss_explosions_still_active = any(ex for ex in explosion_group if ex.rect.colliderect(self.rect) and ex.images and ex.images[0].get_width() > 100)
                if not boss_explosions_still_active :
                     self.kill()
        if self.state != "dying":
            self.mask = pygame.mask.from_surface(self.image)

    def choose_attack_pattern(self, current_time):
        choice = random.choice(["standard", "barrage", "spread"])
        if choice == "standard": self.state = "attack_standard"
        elif choice == "barrage":
            self.state = "attack_barrage"; self.barrage_shots_fired = 0
            self.last_barrage_shot_time = current_time - self.barrage_shot_interval
        elif choice == "spread": self.state = "attack_spread"

    def fire_bullet_type(self, attack_type):
        if boss_shoot_fx: boss_shoot_fx.play()
        fire_pos_x, fire_pos_y = self.rect.centerx, self.rect.bottom - 20
        if attack_type == "standard" or attack_type == "barrage_shot":
            bullet = Enemy_Bullets(fire_pos_x, fire_pos_y, speed=6, scale_w=14, scale_h=20, damage_val=1.0)
            mechabot_bullet_group.add(bullet)
        elif attack_type == "spread":
            angles = [-30, 0, 30]
            for angle_deg in angles:
                bullet_origin_x = fire_pos_x + (angle_deg * 1.5)
                bullet = Enemy_Bullets(bullet_origin_x, fire_pos_y, speed=5, scale_w=12, scale_h=18, damage_val=0.75)
                mechabot_bullet_group.add(bullet)

# Sprite Groups
spaceship_group = pygame.sprite.GroupSingle()
bullet_group = pygame.sprite.Group()
enemy_group = pygame.sprite.Group()
enemy_bullet_group = pygame.sprite.Group()
mechabot_group = pygame.sprite.GroupSingle()
mechabot_bullet_group = pygame.sprite.Group()
explosion_group = pygame.sprite.Group()
enemy_explosion_group = pygame.sprite.Group()

spaceship = None

def create_enemies():
    enemy_group.empty()
    enemy_type = 1
    if current_level == 2: enemy_type = 2
    formation_width = cols * 90 - 30
    start_x = (screen_width - formation_width) / 2
    if start_x < 20: start_x = 20
    for r_idx in range(rows):
        for c_idx in range(cols):
            enemy_x = start_x + c_idx * 90
            enemy_y = 80 + r_idx * 70
            enemy = Enemies(enemy_x, enemy_y, enemy_type)
            enemy_group.add(enemy)

def spawn_mechabot():
    mechabot_group.empty()
    mechabot_bullet_group.empty()
    boss = MechaBot(screen_width / 2, -mechabot_img_orig.get_height() / 2)
    mechabot_group.add(boss)

level_transition_timer = 0
level_transition_line1 = ""
level_transition_line2 = ""
game_state = "main_menu"

def reset_game_for_start():
    global current_level, countdown, lastCount, level_transition_timer, game_state
    global level_transition_line1, level_transition_line2, spaceship, last_enemy_shot
    for group in [spaceship_group, bullet_group, enemy_group, enemy_bullet_group,
                  mechabot_group, mechabot_bullet_group, explosion_group, enemy_explosion_group]:
        group.empty()
    current_level = 1
    countdown = initial_countdown_duration
    lastCount = pygame.time.get_ticks()
    level_transition_timer = 0
    level_transition_line1 = ""
    level_transition_line2 = ""
    last_enemy_shot = pygame.time.get_ticks()
    spaceship = Spaceship(screen_width / 2, screen_height - 100, 3)
    spaceship.revert_to_normal_form()
    spaceship_group.add(spaceship)
    create_enemies()

def draw_main_menu():
    line_spacing = 55
    padding_after_main_title = 70

    h_invadio = font_title.get_height()
    h_option = font30.get_height()
    h_slang = font_slang.get_height()

    total_block_height = (h_invadio +
                          padding_after_main_title +
                          h_option * 3 +
                          line_spacing * 2 +
                          line_spacing +
                          h_slang)

    current_y_top = (screen_height - total_block_height) / 2

    time_color_offset = pygame.time.get_ticks() * 0.004

    invadio_y_top = current_y_top
    draw_multicolor_text("INVADIO", font_title, screen_width / 2, invadio_y_top, purple_blue_palette, time_color_offset, is_centered_horizontally=True)
    current_y_top += h_invadio + padding_after_main_title

    option_bob_offset = math.sin(pygame.time.get_ticks() * 0.0015) * 4

    option1_y_center = current_y_top + h_option / 2
    draw_text("Press 1 to Start Game", font30, white, screen_width / 2, option1_y_center + option_bob_offset, center=True)
    current_y_top += h_option + line_spacing

    option2_y_center = current_y_top + h_option / 2
    draw_text("Press 2 for Authors", font30, white, screen_width / 2, option2_y_center + option_bob_offset, center=True)
    current_y_top += h_option + line_spacing

    option3_y_center = current_y_top + h_option / 2
    draw_text("Press 3 to Quit", font30, white, screen_width / 2, option3_y_center + option_bob_offset, center=True)
    current_y_top += h_option + line_spacing

    slang_y_top = current_y_top
    draw_multicolor_text("BLAST THE INVADERS!", font_slang, screen_width / 2, slang_y_top, purple_blue_palette, time_color_offset, is_centered_horizontally=True)


def draw_authors_screen():
    time_color_offset = pygame.time.get_ticks() * 0.004
    option_bob_offset = math.sin(pygame.time.get_ticks() * 0.0015) * 3

    authors_title_y_center = screen_height * 0.15
    authors_title_y_top = authors_title_y_center - font_authors_section_title.get_height() / 2
    draw_multicolor_text("Invadio's Authors", font_authors_section_title, screen_width / 2, authors_title_y_top, purple_blue_palette, time_color_offset, is_centered_horizontally=True)

    text_start_y_authors = authors_title_y_center + font_authors_section_title.get_height() / 2 + 40
    info_line_spacing = 40

    authors_info = [
        "Dania Kartini Raharjo - 2702287081",
        "Esther Regina Sudargo - 2702305815",
        "Steven Jonatan - 2702278240"
    ]
    current_y = text_start_y_authors
    for author in authors_info:
        draw_text(author, font_instructions, instruction_color, screen_width / 2, current_y + option_bob_offset, center=True)
        current_y += info_line_spacing

    supervisor_title_y_center = current_y + 40
    supervisor_title_y_top = supervisor_title_y_center - font_authors_section_title.get_height() / 2
    draw_multicolor_text("Supervisor/Lecturer:", font_authors_section_title, screen_width / 2, supervisor_title_y_top, purple_blue_palette, time_color_offset, is_centered_horizontally=True)

    supervisor_name_y = supervisor_title_y_center + font_authors_section_title.get_height() / 2 + 30
    draw_text("Eric Savero Hermawan, S.Kom, M.Kom.", font_instructions, instruction_color, screen_width / 2, supervisor_name_y + option_bob_offset, center=True)

    esc_y = supervisor_name_y + info_line_spacing + 50
    draw_text("Press ESC to Return to Main Menu", font_instructions, white, screen_width / 2, esc_y + option_bob_offset, center=True)


run = True
while run:
    current_time = pygame.time.get_ticks()
    clock.tick(fps)
    for event in pygame.event.get():
        if event.type == pygame.QUIT: run = False
        if event.type == pygame.KEYDOWN:
            if game_state == "main_menu":
                if event.key == pygame.K_1:
                    reset_game_for_start(); game_state = "playing"
                elif event.key == pygame.K_2: game_state = "authors_screen"
                elif event.key == pygame.K_3: run = False
            elif game_state == "authors_screen":
                if event.key == pygame.K_ESCAPE: game_state = "main_menu"
            elif game_state == "game_over" or game_state == "game_won":
                if event.key == pygame.K_r:
                    reset_game_for_start(); game_state = "playing"
                elif event.key == pygame.K_3: run = False

    draw_bg()

    if game_state == "main_menu":
        draw_main_menu()
    elif game_state == "authors_screen":
        draw_authors_screen()
    elif game_state == "playing":
        if countdown > 0:
            if spaceship_group.sprite: spaceship_group.draw(screen)
            enemy_group.draw(screen)
            if current_level == 3 and mechabot_group.sprite and mechabot_group.sprite.state == "entering":
                mechabot_group.update()
                mechabot_group.draw(screen)

            level_text_y_pos = screen_height * 0.35
            get_ready_y_pos = level_text_y_pos + 60
            countdown_num_y_pos = get_ready_y_pos + 60
            instructions_y_pos = countdown_num_y_pos + 70

            level_txt = f"LEVEL {current_level}"
            if current_level == 3 and not (level_transition_timer > 0 and "BOSS" in level_transition_line2):
                 level_txt = "FINAL BOSS"
            draw_text(level_txt, font40, white, screen_width/2, level_text_y_pos, center=True)
            draw_text('GET READY!', font40, white, screen_width/2, get_ready_y_pos, center=True)
            draw_text(str(countdown), font40, white, screen_width/2, countdown_num_y_pos, center=True)
            draw_text("Arrow Keys to Move", font_instructions, instruction_color, screen_width/2, instructions_y_pos, center=True)
            draw_text("Space to Shoot", font_instructions, instruction_color, screen_width/2, instructions_y_pos + 30, center=True)

            if current_time - lastCount > 1000:
                countdown -= 1; lastCount = current_time

        elif level_transition_timer > 0:
            if spaceship_group.sprite: spaceship_group.draw(screen)
            if current_level == 3 and "BOSS APPROACHING!" in level_transition_line2 and \
               mechabot_group.sprite and mechabot_group.sprite.alive() and mechabot_group.sprite.state == "entering":
                mechabot_group.update()
                mechabot_group.draw(screen)

            if level_transition_line2:
                draw_text(level_transition_line1, font40, white, screen_width/2, screen_height/2 - 20, center=True)
                draw_text(level_transition_line2, font40, white, screen_width/2, screen_height/2 + 20, center=True)
            else:
                draw_text(level_transition_line1, font40, white, screen_width/2, screen_height/2, center=True)

            if current_time - lastCount > 2500:
                level_transition_timer = 0; countdown = initial_countdown_duration
                lastCount = current_time; level_transition_line1 = ""; level_transition_line2 = ""
        else:
            if spaceship_group.sprite and spaceship_group.sprite.alive():
                if spaceship_group.sprite.update(): game_state = "game_over"
            elif not spaceship_group.sprite and game_state == "playing": game_state = "game_over"

            if game_state == "playing":
                if current_level == 1 or current_level == 2:
                    active_cooldown = enemy_cooldown_level1 if current_level == 1 else enemy_cooldown_level2
                    max_buls = 3 if current_level == 1 else 5
                    if current_time - last_enemy_shot > active_cooldown and \
                       len(enemy_bullet_group) < max_buls and len(enemy_group) > 0:
                        attacker = random.choice(enemy_group.sprites())
                        bullet_spd = 3 if current_level == 1 else 4.5
                        enemy_bullet_group.add(Enemy_Bullets(attacker.rect.centerx, attacker.rect.bottom, bullet_spd))
                        last_enemy_shot = current_time
                    enemy_group.update()
                    if len(enemy_group) == 0:
                        if current_level == 1:
                            current_level = 2; level_transition_line1 = "LEVEL 1 CLEARED!"; level_transition_line2 = ""
                        elif current_level == 2:
                            current_level = 3; level_transition_line1 = "LEVEL 2 CLEARED!"; level_transition_line2 = "BOSS APPROACHING!"
                        if spaceship_group.sprite:
                            spaceship_group.sprite.health_remain = spaceship_group.sprite.health_start
                            if current_level == 3: spaceship_group.sprite.morph_to_level3_form()
                        level_transition_timer = current_time; lastCount = current_time
                        last_enemy_shot = current_time; bullet_group.empty(); enemy_bullet_group.empty()
                        if current_level == 3: spawn_mechabot()
                        else: create_enemies()
                elif current_level == 3:
                    if mechabot_group.sprite and mechabot_group.sprite.alive(): mechabot_group.update()
                    elif not mechabot_group.sprite and game_state == "playing": game_state = "game_won"
                bullet_group.update()
                enemy_bullet_group.update()
                if current_level == 3: mechabot_bullet_group.update()

        if not (countdown > 0 or level_transition_timer > 0):
            enemy_group.draw(screen)
            if spaceship_group.sprite: spaceship_group.draw(screen)
            mechabot_group.draw(screen)

        if spaceship_group.sprite and spaceship_group.sprite.alive():
            draw_player_health_bar(spaceship_group.sprite)
        bullet_group.draw(screen)
        enemy_bullet_group.draw(screen)
        mechabot_bullet_group.draw(screen)
        if current_level == 3 and mechabot_group.sprite and mechabot_group.sprite.alive():
            draw_boss_health_bar(mechabot_group.sprite)
        explosion_group.update(); explosion_group.draw(screen)
        enemy_explosion_group.update(); enemy_explosion_group.draw(screen)

    elif game_state == "game_over":
        draw_text('GAME OVER!', font40, white, screen_width/2, screen_height/2 - 40, center=True)
        draw_text('Press R to Restart', font30, white, screen_width/2, screen_height/2 + 20, center=True)
        draw_text('Press 3 to Quit', font30, white, screen_width/2, screen_height/2 + 60, center=True)
        explosion_group.update(); explosion_group.draw(screen)
        enemy_explosion_group.update(); enemy_explosion_group.draw(screen)
    elif game_state == "game_won":
        draw_text('YOU WIN!', font40, white, screen_width/2, screen_height/2 - 40, center=True)
        draw_text('Press R to Restart', font30, white, screen_width/2, screen_height/2 + 20, center=True)
        draw_text('Press 3 to Quit', font30, white, screen_width/2, screen_height/2 + 60, center=True)
        explosion_group.update(); explosion_group.draw(screen)
        enemy_explosion_group.update(); enemy_explosion_group.draw(screen)

    pygame.display.flip()
pygame.quit()